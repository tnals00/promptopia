import React from "react";

const layout = () => {
  return <div>Hello</div>;
};

export default layout;
